# Massa wallet

Web Extension for Chrome and Firefox

## Installation

Chrome:
  - Type chrome://extensions in the adress bar
  - Click on "Load Unpacked"
  - Select the massa-wallet folder

- Firefox:
  - Type about:debugging in the adress bar
  - Click on "This Firefox"
  - Click on "Load Temporary Add-on..."
  - Select the file `manifest.json` in the massa-wallet folder

## Usage

Once the extension is installed, you should see the Massa icon on the top right of your browser.

The extension allows you to browse decentralized website using your node or a remote node.

For instance select the labnet network and type massa://life in your address bar.

N.B : For now, for convenience, the password is pre-filled to simplify testing (DefaultP@ssword123).
