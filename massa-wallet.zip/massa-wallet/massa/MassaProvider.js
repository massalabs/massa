//TODO : implement provider methods like Metamask :
//https://docs.metamask.io/guide/ethereum-provider.html#events
//Instance will be injected in window.massa

class MassaProvider
{
    constructor()
    {

    }

    request({ method, params })
    {
        //TODO
        if (method == 'sendTransaction')
        {

        }
    }
}

export default MassaProvider;